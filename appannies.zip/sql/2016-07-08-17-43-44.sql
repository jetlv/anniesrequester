insert into app_rank (app_id, rank, rank_date, rank_type, country, category) values("50600001000017","1","20160707","Free","AO","lifestyle");
insert into app_rank (app_id, rank, rank_date, rank_type, country, category) values("50600001003763","1","20160707","Grossing","AO","lifestyle");
insert into app_rank (app_id, rank, rank_date, rank_type, country, category) values("50600001001081","3","20160707","Grossing","AO","lifestyle");
insert into app_rank (app_id, rank, rank_date, rank_type, country, category) values("50600001001023","4","20160707","Free","AO","lifestyle");
insert into app_rank (app_id, rank, rank_date, rank_type, country, category) values("50600001000017","2","20160707","Grossing","AO","lifestyle");
insert into app_rank (app_id, rank, rank_date, rank_type, country, category) values("50600001001023","4","20160707","Grossing","AO","lifestyle");
insert into app_rank (app_id, rank, rank_date, rank_type, country, category) values("50600001003763","2","20160707","Free","AO","lifestyle");
insert into app_rank (app_id, rank, rank_date, rank_type, country, category) values("50600001001081","3","20160707","Free","AO","lifestyle");
